import { Action, IUpdateStateFunction } from '../action.class';
import { Store } from '../store.class';

export class DeferredAction<GState, GArguments extends any[]> {
  protected _update: IUpdateStateFunction<GState, GArguments>;

  constructor(
    update: IUpdateStateFunction<GState, GArguments>,
  ) {
    this._update = update;
  }

  create(
    store: Store<GState>,
  ): Action<GState, GArguments> {
    return new Action<GState, GArguments>(
      store,
      this._update,
    );
  }
}
