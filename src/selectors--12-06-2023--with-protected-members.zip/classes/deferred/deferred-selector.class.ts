import { ISelectFunction, Selector } from '../selector.class';
import { Store } from '../store.class';

export class DeferredSelector<GState, GValue> {
  protected _map: ISelectFunction<GState, GValue>;

  constructor(
    map: ISelectFunction<GState, GValue>,
  ) {
    this._map = map;
  }

  create(
    store: Store<GState>,
  ): Selector<GState, GValue> {
    return new Selector<GState, GValue>(
      store,
      this._map,
    );
  }
}
