export type ImmutableArray<GValue> = readonly GValue[];

