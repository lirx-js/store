import { IAsyncTaskConstraint } from '@lirx/async-task';
import { Store } from '../../store/store.class';
import { IAsyncUpdateStateFunction } from '../../store/types/async-update-state-function.type';
import { IAsyncActionOptions } from '../../store/types/async-action-options.type';
import { IInvokeAsyncActionFunction } from '../../store/types/invoke-async-action-function.type';

export class AsyncAction<GState extends IAsyncTaskConstraint<GState>, GArgument> {
  readonly #update: IAsyncUpdateStateFunction<GState, GArgument>;
  readonly #options: IAsyncActionOptions | undefined;

  constructor(
    update: IAsyncUpdateStateFunction<GState, GArgument>,
    options?: IAsyncActionOptions,
  ) {
    this.#update = update;
    this.#options = options;
  }

  create(
    store: Store<GState>,
  ): IInvokeAsyncActionFunction<GArgument> {
    return store.asyncAction<GArgument>(
      this.#update,
      this.#options,
    );
  }
}
