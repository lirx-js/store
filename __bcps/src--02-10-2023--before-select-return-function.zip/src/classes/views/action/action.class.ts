import { Store } from '../../store/store.class';
import { IUpdateStateFunction } from '../../store/types/update-state-function.type';
import { IInvokeActionFunction } from '../../store/types/invoke-action-function.type';

export class Action<GState, GArguments extends readonly any[]> {
  readonly #update: IUpdateStateFunction<GState, GArguments>;

  constructor(
    update: IUpdateStateFunction<GState, GArguments>,
  ) {
    this.#update = update;
  }

  create(
    store: Store<GState>,
  ): IInvokeActionFunction<GArguments> {
    return store.action<GArguments>(
      this.#update,
    );
  }
}
