import { ISelectFunction } from '../../store/types/select-function.type';
import { ISelectOptions } from '../../store/types/select-options.type';
import { ReadonlyStore } from '../../store/readonly-store.class';

export class Selector<GState, GSelectedState> {
  readonly #map: ISelectFunction<GState, GSelectedState>;
  readonly #options: ISelectOptions<GSelectedState> | undefined;

  constructor(
    map: ISelectFunction<GState, GSelectedState>,
    options?: ISelectOptions<GSelectedState>,
  ) {
    this.#map = map;
    this.#options = options;
  }

  create(
    store: ReadonlyStore<GState>,
  ): ReadonlyStore<GSelectedState> {
    return store.select<GSelectedState>(
      this.#map,
      this.#options,
    );
  }

  select<GSubSelectedState>(
    map: ISelectFunction<GSelectedState, GSubSelectedState>,
    options?: ISelectOptions<GSubSelectedState>,
  ): Selector<GState, GSubSelectedState> {
    return new Selector<GState, GSubSelectedState>(
      (
        state: GState,
      ): GSubSelectedState => {
        return map(this.#map(state));
      },
      options,
    );
  }
}

