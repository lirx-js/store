import { IDistinctEqualFunctionOptions } from '@lirx/utils';

export interface ISelectOptions<GState> extends IDistinctEqualFunctionOptions<GState> {
}
