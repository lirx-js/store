export interface IInvokeActionFunction<GArguments extends readonly any[]> {
  (
    ...args: GArguments
  ): void;
}

