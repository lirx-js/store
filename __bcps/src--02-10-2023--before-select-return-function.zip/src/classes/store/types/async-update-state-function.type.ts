import { Abortable, IAsyncTaskInput } from '@lirx/async-task';
import { IReadStateFunction } from './read-state-function.type';
import { IWriteStateFunction } from './write-state-function.type';

export interface IAsyncUpdateStateFunction<GState, GArgument> {
  (
    arg: GArgument,
    read: IReadStateFunction<GState>,
    write: IWriteStateFunction<GState>,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}
