import { IMapFunction } from '@lirx/core';

export type ISelectFunction<GState, GSelectedState> = IMapFunction<GState, GStateGSelectedState>;

export interface ISelectMapFunction<GState, GArguments extends readonly any[], GSelectedState> {
  (
    value: GState,
    ...args: GArguments
  ): GSelectedState;
}
