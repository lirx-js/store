export interface IUpdateStateFunction<GState, GArguments extends readonly any[]> {
  (
    state: GState,
    ...args: GArguments
  ): GState,
}
