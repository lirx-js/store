import { createMulticastReplayLastSource, IObserver } from '@lirx/core';
import { ReadonlyStore, IReadonlyStoreInput } from './readonly-store.class';
import { IUpdateStateFunction } from './types/update-state-function.type';
import { IInvokeActionFunction } from './types/invoke-action-function.type';
import { IInvokeAsyncActionFunction } from './types/invoke-async-action-function.type';
import { Abortable, AsyncTask, IAsyncTaskInput } from '@lirx/async-task';
import { IAsyncUpdateStateFunction } from './types/async-update-state-function.type';
import { IGenericFunction, noop } from '@lirx/utils';
import { IAsyncActionOptions } from './types/async-action-options.type';

/** TYPES**/

export interface IStoreInput<GState> extends IReadonlyStoreInput<GState> {
  readonly emit: IObserver<GState>;
}

/** CLASS **/

export class Store<GState> extends ReadonlyStore<GState> {

  static create<GState>(
    initialState: GState,
  ): Store<GState> {
    return new Store<GState>(
      createMulticastReplayLastSource<GState>(initialState),
    );
  }

  readonly #$state: IObserver<GState>;
  #queue: AsyncTask<void>;

  constructor(
    {
      emit,
      ...options
    }: IStoreInput<GState>,
  ) {
    super(options);
    this.#$state = emit;
    this.#queue = AsyncTask.void(Abortable.never);
  }

  get $state(): IObserver<GState> {
    return this.#$state;
  }

  get state(): GState {
    return super.state;
  }

  set state(
    value: GState,
  ) {
    this.#$state(value);
  }

  action<GArguments extends readonly any[]>(
    update: IUpdateStateFunction<GState, GArguments>,
  ): IInvokeActionFunction<GArguments> {
    return (
      ...args: GArguments
    ): void => {
      return this.#$state(
        update(
          this.state,
          ...args,
        ),
      );
    };
  }

  asyncAction<GArgument>(
    update: IAsyncUpdateStateFunction<GState, GArgument>,
    {
      queue = true,
    }: IAsyncActionOptions = {},
  ): IInvokeAsyncActionFunction<GArgument> {
    const invoke: IInvokeAsyncActionFunction<GArgument> = (
      arg: GArgument,
      abortable: Abortable,
    ): AsyncTask<void> => {
      let running: boolean = true;

      const wrapFunctionWithRunning = <GFunction extends IGenericFunction>(fnc: GFunction): GFunction => {
        return (function(this: any, ...args: any[]): ReturnType<GFunction> {
          if (running) {
            return fnc.apply(this, args);
          } else {
            throw new Error(`AsyncAction.invoke is done.`);
          }
        }) as GFunction;
      };

      return AsyncTask.fromFactory((abortable: Abortable): IAsyncTaskInput<void> => {
        return update(
          arg,
          wrapFunctionWithRunning(this.getState),
          wrapFunctionWithRunning(this.#$state),
          abortable,
        );
      }, abortable)
        .finally((): void => {
          running = false;
        });
    };

    if (queue) {
      return (
        arg: GArgument,
        abortable: Abortable,
      ): AsyncTask<void> => {
        return this.#queue = AsyncTask.switchAbortable(
          this.#queue
            .errored(noop),
          abortable,
        )
          .successful((_, abortable: Abortable): AsyncTask<void> => {
            return invoke(arg, abortable);
          });
      };
    } else {
      return invoke;
    }
  }
}

