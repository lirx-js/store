import { IObservable, mapDistinctObservable } from '@lirx/core';
import { IReadStateFunction } from './types/read-state-function.type';
import { EQUAL_FUNCTION_STRICT_EQUAL } from '@lirx/utils';
import { ISelectFunction } from './types/select-function.type';
import { ISelectOptions } from './types/select-options.type';

/** TYPES **/

export interface IReadonlyStoreInput<GState> {
  readonly getValue: IReadStateFunction<GState>;
  readonly subscribe: IObservable<GState>;
}

/** CLASS **/

export class ReadonlyStore<GState> {
  readonly #getState: IReadStateFunction<GState>;
  readonly #state$: IObservable<GState>;

  constructor(
    {
      getValue,
      subscribe,
    }: IReadonlyStoreInput<GState>,
  ) {
    this.#getState = getValue;
    this.#state$ = subscribe;
  }

  get getState(): IReadStateFunction<GState> {
    return this.#getState;
  }

  get state$(): IObservable<GState> {
    return this.#state$;
  }

  get state(): GState {
    return this.#getState();
  }

  select<GSelectedState>(
    map: ISelectFunction<GState, GSelectedState>,
    {
      equal = EQUAL_FUNCTION_STRICT_EQUAL,
    }: ISelectOptions<GSelectedState> | undefined = {},
  ): ReadonlyStore<GSelectedState> {
    return new ReadonlyStore<GSelectedState>({
      getValue: (): GSelectedState => {
        return map(this.#getState());
      },
      subscribe: mapDistinctObservable(
        this.#state$,
        map,
        {
          equal,
        },
      ),
    });
  }

  // export function isFileSelected$$(
  //   store: Store<any>,
  // ): any {
  //   return (id: string): IObservable<boolean> => {
  //     return pipe$$(selectedFileIdsSelector.create(store).state$, [
  //       // debounceFrame$$$(),
  //       // throttleTime$$$(50),
  //       map$$$((selectedFile: ISelectedFileIds): boolean => {
  //         return selectedFile.has(id);
  //       }),
  //     ]);
  //   };
  // }

  map<GArguments extends readonly any[], GSelectedState>(
    map: ISelectFunction<GState, GSelectedState>,
    options?: ISelectOptions<GSelectedState> | undefined,
  ): ReadonlyStore<GSelectedState> {
    return (id: string): IObservable<boolean> => {
      return mapDistinctObservable();
      return pipe$$(selectedFileIdsSelector.create(store).state$, [
        // debounceFrame$$$(),
        // throttleTime$$$(50),
        map$$$((selectedFile: ISelectedFileIds): boolean => {
          return selectedFile.has(id);
        }),
      ]);
    };
  }
}

