export type Immutable<GValue> = Readonly<GValue>;
