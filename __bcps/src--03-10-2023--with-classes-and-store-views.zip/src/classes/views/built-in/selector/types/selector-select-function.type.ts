import { ReadonlyStore } from '../../../../store/readonly-store.class';

export interface ISelectorSelectFunction<GState, GSelectedState> {
  (
    store: ReadonlyStore<GState>,
  ): GSelectedState,
}

