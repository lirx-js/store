import { IDistinctEqualFunctionOptions } from '@lirx/utils';

export interface ISelectorOptions<GState> extends IDistinctEqualFunctionOptions<GState> {
}
