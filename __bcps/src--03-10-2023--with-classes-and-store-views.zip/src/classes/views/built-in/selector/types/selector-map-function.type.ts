import { IMapFunction } from '@lirx/core';

export type ISelectorMapFunction<GState, GSelectedState> = IMapFunction<GState, GSelectedState>;

