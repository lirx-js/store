import { ISelectorMapFunction } from './types/selector-map-function.type';
import { ISelectorOptions } from './types/selector-options.type';
import { ReadonlyStore } from '../../../store/readonly-store.class';
import { mapDistinctObservable, IObservable } from '@lirx/core';
import { EQUAL_FUNCTION_STRICT_EQUAL } from '@lirx/utils';
import { StoreView } from '../../store-view.class';
import { ISelectorSelectFunction } from './types/selector-select-function.type';

export class Selector<GState, GSelectedState> extends StoreView<ReadonlyStore<GState>, IObservable<GSelectedState>> {
  readonly #select: ISelectorSelectFunction<GState, GSelectedState>;

  constructor(
    map: ISelectorMapFunction<GState, GSelectedState>,
    {
      equal = EQUAL_FUNCTION_STRICT_EQUAL,
    }: ISelectorOptions<GSelectedState> | undefined = {},
  ) {
    super(
      (
        store: ReadonlyStore<GState>,
      ): IObservable<GSelectedState> => {
        return mapDistinctObservable(
          store.state$,
          map,
          {
            equal,
          },
        );
      },
    );

    this.#select = (
      store: ReadonlyStore<GState>,
    ): GSelectedState => {
      return map(
        store.state,
      );
    };

  }

  get select(): ISelectorSelectFunction<GState, GSelectedState> {
    return this.#select;
  }
}

