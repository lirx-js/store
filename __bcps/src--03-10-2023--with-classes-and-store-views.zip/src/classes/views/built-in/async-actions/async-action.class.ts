import { IAsyncTaskConstraint, AsyncTask, Abortable, IAsyncTaskInput } from '@lirx/async-task';
import { Store } from '../../../store/store.class';
import { IAsyncActionUpdateStateFunction } from './types/async-action-update-state-function.type';
import { IAsyncActionOptions } from './types/async-action-options.type';
import { IAsyncActionFunction } from './types/async-action-function.type';
import { IGenericFunction, noop } from '@lirx/utils';
import { StoreView } from '../../store-view.class';

const QUEUE = new WeakMap<Store<any>, AsyncTask<void>>;

export class AsyncAction<GState extends IAsyncTaskConstraint<GState>, GArgument> extends StoreView<Store<GState>, IAsyncActionFunction<GArgument>> {
  constructor(
    update: IAsyncActionUpdateStateFunction<GState, GArgument>,
    {
      queue = true,
    }: IAsyncActionOptions | undefined = {},
  ) {

    super(
      (
        store: Store<GState>,
      ): IAsyncActionFunction<GArgument> => {
        const invoke: IAsyncActionFunction<GArgument> = (
          arg: GArgument,
          abortable: Abortable,
        ): AsyncTask<void> => {
          let running: boolean = true;

          const wrapFunctionWithRunning = <GFunction extends IGenericFunction>(fnc: GFunction): GFunction => {
            return (function(this: any, ...args: any[]): ReturnType<GFunction> {
              if (running) {
                return fnc.apply(this, args);
              } else {
                throw new Error(`AsyncAction.invoke is done.`);
              }
            }) as GFunction;
          };

          return AsyncTask.fromFactory((abortable: Abortable): IAsyncTaskInput<void> => {
            return update(
              arg,
              wrapFunctionWithRunning(store.getState),
              wrapFunctionWithRunning(store.$state),
              abortable,
            );
          }, abortable)
            .finally((): void => {
              running = false;
            });
        };

        if (queue) {
          return (
            arg: GArgument,
            abortable: Abortable,
          ): AsyncTask<void> => {
            let asyncTask: AsyncTask<void> | undefined = QUEUE.get(store);

            if (asyncTask === void 0) {
              asyncTask = invoke(arg, abortable);
            } else {
              asyncTask = AsyncTask.switchAbortable(
                asyncTask
                  .errored(noop),
                abortable,
              )
                .successful((_, abortable: Abortable): AsyncTask<void> => {
                  return invoke(arg, abortable);
                });
            }

            QUEUE.set(
              store,
              asyncTask,
            );

            return asyncTask;
          };
        } else {
          return invoke;
        }
      },
    );
  }
}
