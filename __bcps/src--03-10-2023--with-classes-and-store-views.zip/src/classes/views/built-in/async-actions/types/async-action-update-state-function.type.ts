import { Abortable, IAsyncTaskInput } from '@lirx/async-task';
import { IReadStateFunction } from '../../../../store/types/read-state-function.type';
import { IWriteStateFunction } from '../../../../store/types/write-state-function.type';

export interface IAsyncActionUpdateStateFunction<GState, GArgument> {
  (
    arg: GArgument,
    read: IReadStateFunction<GState>,
    write: IWriteStateFunction<GState>,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}
