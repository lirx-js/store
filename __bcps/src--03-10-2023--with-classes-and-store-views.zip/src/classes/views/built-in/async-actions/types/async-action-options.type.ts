export interface IAsyncActionOptions {
  queue?: boolean; // (default: true)
}
