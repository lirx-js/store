import { Abortable, AsyncTask } from '@lirx/async-task';

export interface IAsyncActionFunction<GArgument> {
  (
    arg: GArgument,
    abortable: Abortable,
  ): AsyncTask<void>;
}

