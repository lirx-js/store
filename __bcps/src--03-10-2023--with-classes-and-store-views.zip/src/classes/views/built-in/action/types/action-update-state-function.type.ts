export interface IActionUpdateStateFunction<GState, GArguments extends readonly any[]> {
  (
    state: GState,
    ...args: GArguments
  ): GState,
}
