export interface IActionFunction<GArguments extends readonly any[]> {
  (
    ...args: GArguments
  ): void;
}

