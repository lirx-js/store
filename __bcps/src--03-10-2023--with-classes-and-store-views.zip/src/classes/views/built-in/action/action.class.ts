import { Store } from '../../../store/store.class';
import { IActionUpdateStateFunction } from './types/action-update-state-function.type';
import { IActionFunction } from './types/action-function.type';
import { StoreView } from '../../store-view.class';

export class Action<GState, GArguments extends readonly any[]> extends StoreView<Store<GState>, IActionFunction<GArguments>> {
  constructor(
    update: IActionUpdateStateFunction<GState, GArguments>,
  ) {
    super(
      (
        store: Store<GState>,
      ): IActionFunction<GArguments> => {
        return (
          ...args: GArguments
        ): void => {
          return store.$state(
            update(
              store.state,
              ...args,
            ),
          );
        };
      },
    );
  }
}
