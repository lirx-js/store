export interface IMapperMapFunction<GState, GArguments extends readonly any[], GSelectedState> {
  (
    state: GState,
    ...args: GArguments
  ): GSelectedState;
}

