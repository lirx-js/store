import { IDistinctEqualFunctionOptions } from '@lirx/utils';

export interface IMapperOptions<GState> extends IDistinctEqualFunctionOptions<GState> {
}
