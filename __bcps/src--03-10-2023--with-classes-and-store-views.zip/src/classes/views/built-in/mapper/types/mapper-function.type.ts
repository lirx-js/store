import { IObservable } from '@lirx/core';

export interface IMapperFunction<GArguments extends readonly any[], GSelectedState> {
  (
    ...args: GArguments
  ): IObservable<GSelectedState>;
}
