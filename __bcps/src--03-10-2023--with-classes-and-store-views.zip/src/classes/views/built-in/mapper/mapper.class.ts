import { ReadonlyStore } from '../../../store/readonly-store.class';
import { mapDistinctObservable, IObservable } from '@lirx/core';
import { EQUAL_FUNCTION_STRICT_EQUAL } from '@lirx/utils';
import { IMapperOptions } from './types/mapper-options.type';
import { IMapperMapFunction } from './types/mapper-map-function.type';
import { IMapperFunction } from './types/mapper-function.type';
import { StoreView } from '../../store-view.class';

export class Mapper<GState, GArguments extends readonly any[], GSelectedState> extends StoreView<ReadonlyStore<GState>, IMapperFunction<GArguments, GSelectedState>> {
  constructor(
    map: IMapperMapFunction<GState, GArguments, GSelectedState>,
    {
      equal = EQUAL_FUNCTION_STRICT_EQUAL,
    }: IMapperOptions<GSelectedState> | undefined = {},
  ) {
    super(
      (
        store: ReadonlyStore<GState>,
      ): IMapperFunction<GArguments, GSelectedState> => {
        return (
          ...args: GArguments
        ): IObservable<GSelectedState> => {
          return mapDistinctObservable(
            store.state$,
            (
              state: GState,
            ): GSelectedState => {
              return map(
                state,
                ...args,
              );
            },
            {
              equal,
            },
          );
        };
      },
    );
  }
}

