import { ReadonlyStore } from '../../store/readonly-store.class';

export interface IStoreViewCreateFunction<GStore extends ReadonlyStore<any>, GReturn> {
  (
    store: GStore,
  ): GReturn;
}
