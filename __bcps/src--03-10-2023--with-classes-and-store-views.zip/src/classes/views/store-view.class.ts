import { ReadonlyStore } from '../store/readonly-store.class';
import { IStoreViewCreateFunction } from './types/store-view-create-function.type';

export class StoreView<GStore extends ReadonlyStore<any>, GReturn> {
  readonly #create: IStoreViewCreateFunction<GStore, GReturn>;

  constructor(
    create: IStoreViewCreateFunction<GStore, GReturn>,
  ) {
    this.#create = create;
  }

  get create(): IStoreViewCreateFunction<GStore, GReturn> {
    return this.#create;
  }
}

