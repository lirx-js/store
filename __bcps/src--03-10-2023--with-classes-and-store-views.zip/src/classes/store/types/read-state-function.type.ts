export interface IReadStateFunction<GState> {
  (): GState;
}
